<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateDemographicsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('demographics', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('fname');
			$table->string('lname');
			// $table->string('cnic');
			$table->string('phone');
			// $table->string('home_phon_no');
			// $table->string('reference_phon_no');
			$table->string('email');
			// $table->string('secret_question');
			$table->string('answer');
			// $table->string('address');
			// $table->string('experience');
			$table->string('password');
			$table->string('repass');
			$table->string('city');
			$table->string('country');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('demographics');
	}

}
