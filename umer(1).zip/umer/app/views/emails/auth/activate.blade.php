Hello{{$userName}}, </br></br>

Please Activate Your Account by Using The Link Given Below.


---</br>
{{$link}}</br>
---