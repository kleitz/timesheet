
<form action='users/store'>
<input type='text'>
<input type ='submit'>
</form>