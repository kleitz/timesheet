@extends('licennses.layouts.pendingTimesheets_temp')



@section('navbar')

	<li><a href="#">Create Timesheet</a></li>
	<li><a href="#">Fill Timesheet</a></li>
	<li class="active"><a href="#">Pending Timesheets</a></li>
	<li><a href="#">Old Personal Timesheets</a></li>
	<li><a href="#">Accepted Timesheets</a></li>
	<li><a class="btn" href="index">SIGN OUT</a></li>
@endsection




@section('content')
	<h4 style='margin-left:80.7%; margin-right:6%; margin-top:1%; margin-bottom:-1%' >Welcome! Asad Ullah</h4>	

	

@endsection