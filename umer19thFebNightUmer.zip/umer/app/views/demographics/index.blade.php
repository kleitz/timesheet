@extends('layouts.main')


@section('contents')
		{{var_dump($demographics)}}
@stop